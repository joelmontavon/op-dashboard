var app = angular.module('app', [
  'ngSanitize',
  'ui.utils.masks',
  'utilityServices',
  'dataServices',
  'chartServices',
  'filters',
  'controllers'
]);